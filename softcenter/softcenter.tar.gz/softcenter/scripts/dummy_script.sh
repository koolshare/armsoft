#!/bin/sh
export KSROOT=/koolshare
source $KSROOT/scripts/base.sh

http_response "$1"