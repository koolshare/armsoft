#!/bin/sh
source /koolshare/scripts/base.sh

rm -rf /koolshare/res/icon-rog.png
rm -rf /koolshare/scripts/rog_*.sh
rm -rf /koolshare/webs/Module_rog.asp
rm -rf /tmp/rog*

