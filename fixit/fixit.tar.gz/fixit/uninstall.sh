#!/bin/sh

rm -rf /koolshare/res/icon-fixit.png >/dev/null 2>&1
rm -rf /koolshare/bin/fixit >/dev/null 2>&1 
rm -rf /koolshare/scripts/fixit_config >/dev/null 2>&1 
rm -rf /koolshare/webs/Module_fixit.asp >/dev/null 2>&1
rm -rf /koolshare/scripts/uninstall_fixit.sh >/dev/null 2>&1
rm -rf /tmp/fixit* >/dev/null 2>&1
